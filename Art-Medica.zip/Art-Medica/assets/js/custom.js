$(document).ready(function () {

    AOS.init();

    var swiper = new Swiper(".my-swiper", {
        navigation: {
          nextEl: ".testimonial-slider-controller .swiper-button-next",
          prevEl: ".testimonial-slider-controller .swiper-button-prev",
        },
        pagination: {
            el: ".testimonial-slider-controller .swiper-pagination",
            clickable: true,
        },
    });
    var swiper = new Swiper(".my-swiper2", {
        navigation: {
          nextEl: ".testimonial-slider-controller .swiper-button-next",
          prevEl: ".testimonial-slider-controller .swiper-button-prev",
        },
        pagination: {
            el: ".testimonial-slider-controller .swiper-pagination",
            clickable: true,
        },
    });

    var swiper = new Swiper(".latest-news-holder", {
        slidesPerView: 1,
        spaceBetween: 30,
        breakpoints: {
            640: {
              slidesPerView: 2,
              spaceBetween: 30,
            },
            1024: {
              slidesPerView: 3,
              spaceBetween: 40,
            },
        },
        
    });
    

    let SwiperTop = new Swiper('.swiper-partner', {
        spaceBetween: 0,
        centeredSlides: true,
        speed: 6000,
        autoplay: {
          delay: 1,
        },
        loop: true,
        slidesPerView:'auto',
        allowTouchMove: false,
        disableOnInteraction: true
    });
	
});

$(window).scroll(function() {
	// For Sticky Navbar
    if ($(window).scrollTop() > 300) { 
        $('.header-area').addClass('fixed_header');
    } else {
        $('.header-area').removeClass('fixed_header');
    }
    if ($(window).scrollTop() > 400) {
        $('.header-area').addClass('stky');
    } else {
        $('.header-area').removeClass('stky');
    }
});

$(window).on("load resize",function(e){
    if ($(window).width() < 991) {
        $('.before-qoutation-mark').insertBefore('.testimonial-slider-left');
        $('.read-more-button').insertAfter('.testimonial-content-slider-wrapper ');
        $('.morden-practice-content-right').insertBefore('.morden-practice-content-left');
    }
    else {
        $('.before-qoutation-mark').insertBefore('.after-qoutation-mark');
        $('.read-more-button').insertAfter('.testimonial-slider-left ');
        $('.morden-practice-content-right').insertBefore('.reposition-image');
    }
});
// *****************************
$(".accordion > li > span").click(function() {
    $(this).toggleClass("active").next('div').slideToggle(250)
    .closest('li').siblings().find('span').removeClass('active').next('div').slideUp(250);
});
// **************************************
var swiper = new Swiper(".featured-video-swiper", {
    slidesPerView: 1.9,
    spaceBetween: 50,
    cssMode: true,
    navigation: {
      nextEl: ".swiper-button-area .swiper-button-next",
      prevEl: " .swiper-button-area .swiper-button-prev",
    },
    pagination: {
      el: ".swiper-button-area .swiper-pagination",
      clickable: true,
    },
    mousewheel: true,
    keyboard: true,
    breakpoints: {
        320: {
            slidesPerView: 1.5,
          spaceBetween:24,
        },
        768: {
          spaceBetween:40,
          slidesPerView: 1.9,
        },
        992: {
          spaceBetween:50,
        },
    },
  });